Inkception — fully offline photo editor
=======================================
Version: v0.17.32

WHAT THIS IS
  A complete photo editor that runs in your browser with NO internet and
  NO account. Everything is free and stays on your device.

HOW TO USE
  1. Extract this zip into a folder (keep inkception.html and the
     mediapipe/ folder side by side).
  2. Double-click inkception.html — the editor opens.
  3. Everything works: 358 Actions, recipes, collage, filters, effects,
     text, shapes, and all exports (PNG / JPG / WebP / GIF / PDF / PSD / SVG).

AI FEATURES
  Remove Background, Replace Background, Magic Eraser, Smart Crop,
  Decompose, Motion Blur BG run on-device with the included MediaPipe model.
  Browsers block file-to-file reads, so for those six AI features start a
  tiny local server instead of double-clicking:
      python -m http.server        (in this folder)
  then open http://localhost:8000/

TIP
  Inkception auto-saves every 15 s to your browser's local storage — your
  projects survive closing the tab. Use the "What do you want to do today?"
  dropdown in the header to see everything that's possible.
